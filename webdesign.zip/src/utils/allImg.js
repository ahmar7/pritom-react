import Dp from "../assets/img/pritom.94c956fd.png";
import WhatsappIco from "../assets/img/whatsapp.svg";
import TelegramIco from "../assets/img/telegram.svg";
import MailIco from "../assets/img/main.svg";
import JsLogo from "../assets/img/js.93ac64d7.png";
import ReactLogo from "../assets/img/react.png";
import SolidityLogo from "../assets/img/Solidity.4dbd346a.png";
import TensorLogo from "../assets/img/tensor.png";
import RustLogo from "../assets/img/rust.png";
import PaythonLogo from "../assets/img/paython.png";
import ScikictLogo from "../assets/img/Scikit_learn.09376867.png";
import HardoopLogo from "../assets/img/Hadoop_logo.09dede3b.png";
import HardhatLogo from "../assets/img/hardhat.0ca36d6f.png";
import TruffleLogo from "../assets/img/truffle.413b29b5.png";
import FlaskLogo from "../assets/img/Flask.74a77738.png";
import NodeLogo from "../assets/img/node.png";
import Arrow from "../assets/img/arrow.svg";
import CallArrow from "../assets/img/call.svg";
import TimerArrow from "../assets/img/timer.svg";
import LocationArrow from "../assets/img/location.svg";
import GitIco from "../assets/img/git.svg";
import LinkdinIco from "../assets/img/linkdin.svg";
import LinkdinWhiteIco from "../assets/img/linkdinwhite.svg";
import SkypeIco from "../assets/img/skype.svg";
import SkypeWhiteIco from "../assets/img/skypewhite.svg";
import FacebookIco from "../assets/img/facebook.svg";
import Video1 from "../assets/video/3.26422fda.mp4";
import Video2 from "../assets/video/4.a06c1e18.mp4";
import Video3 from "../assets/video/5.9fa994dc.mp4";

export {
  Dp,
  WhatsappIco,
  TelegramIco,
  MailIco,
  JsLogo,
  ReactLogo,
  SolidityLogo,
  TensorLogo,
  RustLogo,
  PaythonLogo,
  ScikictLogo,
  HardoopLogo,
  HardhatLogo,
  TruffleLogo,
  FlaskLogo,
  NodeLogo,
  Arrow,
  CallArrow,
  TimerArrow,
  LocationArrow,
  GitIco,
  LinkdinIco,
  LinkdinWhiteIco,
  SkypeIco,
  SkypeWhiteIco,
  FacebookIco,
  Video1,
  Video2,
  Video3,
};
