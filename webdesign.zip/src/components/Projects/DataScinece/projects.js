import React from "react";
import "./project.css";
const Datascience = () => {
  return (
    <div className="project-section">
      <h2 className="section-heading">Data Science Projects</h2>
      <div className="science-block">
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
        <div className="inner-science">
          <h3>Marriage Registration System</h3>
          <p>
            Marriage-registration-system-using-blockchain-smart-contract:
            Bitcoin has emerged as a disruptive technology with the power to
            revolutionize business and its processes....
          </p>
          <div className="pro-link">
            <a href="">View Project</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Datascience;
